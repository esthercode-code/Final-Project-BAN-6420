README.md
Healthcare Income & Spending Analysis Project
This repository contains the full-stack solution for collecting user income and expense data via a Flask web application, storing it in MongoDB, and performing data analysis and visualization in a Jupyter Notebook using Python.

Project Objective
The goal of this project is to develop an end-to-end data collection and analysis tool to understand participants' income and spending habits, specifically in preparation for a new product launch in the healthcare industry.

To run this project locally and review the analysis, you will need the following installed:

1. Backend & Data Processing
Python 3.8+

MongoDB Atlas Account: A free-tier cluster is sufficient for testing.

Python Libraries: Listed in requirements.txt.

2. Analysis
Jupyter Notebook or JupyterLab.

3. Deployment (For Review)
AWS Account (EC2 instance).

SSH Client (e.g., PuTTY, VS Code SSH extension).

Repository Structure
.
├── app.py                      # Flask application and MongoDB integration code
├── requirements.txt            # Python dependencies (Flask, PyMongo, Pandas, Gunicorn)
├── User.py                     # The Python 'User' class definition
├── analysis_notebook.ipynb     # Jupyter Notebook for data analysis and visualization
├── templates/
│   └── index.html              # The survey collection webpage
├── survey_data_for_analysis.csv# (Generated after running the Flask app)
├── Chart_Ages_Highest_Income.png # Exported chart 1
└── Chart_Gender_Spending_Distribution.png # Exported chart 2

Setup and Execution
Step 1: Clone and Install Dependencies
Clone this repository:


git clone [YOUR_REPOSITORY_LINK]
cd [your_project_directory]
Create and activate a virtual environment (Recommended):


python -m venv venv
source venv/bin/activate  # On Linux/macOS
# venv\Scripts\activate     # On Windows
Install dependencies:

pip install -r requirements.txt

Step 2: Configure MongoDB
Log into your MongoDB Atlas account.

Create a cluster and set up a user/password.

Crucially, update the MONGO_URI variable at the top of the app.py file with your connection string:


MONGO_URI = "mongodb+srv://<username>:<password>@<cluster_url>/survey_db?retryWrites=true&w=majority"
Step 3: Run the Flask Application
Run the application locally:

Bash

python app.py
Open your browser and navigate to http://127.0.0.1:5000/.

Submit at least 5-10 records through the form to generate meaningful data.

Action: When data is submitted, the Flask app inserts the record into MongoDB and automatically calls the export_to_csv() function, creating the required survey_data_for_analysis.csv file.

Step 4: Data Processing and Analysis
Open the analysis_notebook.ipynb file in Jupyter Lab/Notebook.

Run all cells sequentially.

Action: The notebook loads the survey_data_for_analysis.csv, performs the required visualizations, and exports the two charts (Ages_Highest_Income_Chart.png and Gender_Spending_Distribution_Chart.png) to the project root directory.
AWS Deployment (Hosting the Flask Application)
The Flask application is hosted on an Amazon EC2 instance to meet the deployment requirement.


Access Instructions:
The live application can be accessed via the following public IP:

[INSERT YOUR EC2 PUBLIC IP OR DOMAIN HERE]

Code Implementation Details
Python Class: The User class is implemented in app.py (or can be moved to User.py) and is used to abstract and flatten the MongoDB document structure for cleaner CSV export.

Data Structure: MongoDB stores expenses as an embedded dictionary, while the CSV export flattens these into separate columns for ease of analysis in Pandas.

Visualization: Pandas grouping and df.melt() are utilized to prepare the data precisely for the required Seaborn/Matplotlib charts.