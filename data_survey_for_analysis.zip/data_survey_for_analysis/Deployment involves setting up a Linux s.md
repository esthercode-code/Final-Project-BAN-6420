Deployment involves setting up a Linux server on AWS, installing dependencies, and running the application. The most common service for this is Amazon EC2 (Elastic Compute Cloud).

Launch an EC2 Instance:

Select an appropriate AMI (e.g., Ubuntu or Amazon Linux).

Choose an instance type (e.g., t2.micro for a free-tier eligible option).

Crucially, configure the Security Group to allow inbound traffic on:

Port 22 (SSH): For secure shell access.

Port 80 (HTTP): The default web port, or Port 5000 if you skip a reverse proxy (like Nginx).

Setup and Install Dependencies:

SSH into the EC2 instance.

Install Python, pip, and necessary system dependencies (e.g., sudo apt update, sudo apt install python3 python3-pip).

Install your Python libraries (Flask, pymongo, pandas, gunicorn):

Bash

pip install -r requirements.txt
pip install gunicorn # Gunicorn is needed for production hosting
Transfer Code:

Use scp or GitHub to transfer your app.py, templates/, and requirements.txt to the EC2 instance.

Install MongoDB Driver (if necessary):

Ensure your MongoDB Atlas cluster allows connections from your EC2 instance's IP address.

Run the Flask Application with Gunicorn:

Instead of running python app.py, use Gunicorn for production reliability:

Bash

gunicorn --bind 0.0.0.0:80 app:app 
# Binds the application to all interfaces on port 80 or 5000
Optional: Use Nginx as a Reverse Proxy:

For a professional setup, install Nginx to route traffic from port 80 to the Gunicorn process running on port 5000. This adds security and management features.

Final Test:

Access the application using the EC2 Public IP address in your browser.